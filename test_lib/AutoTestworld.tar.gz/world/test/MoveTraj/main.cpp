#include <iostream>
#include "MoveTraj.h"

#include <EwayFunc/FuncSdkLib.h>


using namespace std;



int main(int argc, char *argv[])
{
    cv::Mat i_map;
    vector<CWheelGoToPositionCmd> vCmd;
    MoveTraj traj;

    traj.setStart(-10,-5);
    traj.getMoveTraj(vCmd,i_map);

    cv::imshow("AStar", i_map);
    cv::waitKey(0);

    return 0;
}
