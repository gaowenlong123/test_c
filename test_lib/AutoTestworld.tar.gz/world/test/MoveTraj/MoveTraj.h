#ifndef MOVETRAJ_H
#define MOVETRAJ_H
#include <EwayFunc/FuncSdkLib.h>
#include <iostream>
#include "AStar.h"
#include "ImageTool.h"
#include "MapExpand.h"
#include "MergeTraj.h"


#define zero_X  30
#define zero_Y  10
#define goal_X  29
#define goal_Y  20



using namespace std;
class MoveTraj
{

public:
    MoveTraj();
    void getMoveTraj(vector<CWheelGoToPositionCmd> &vCmd , cv::Mat &iMap);

    eint GetMoveCommand(CWheelGoToPositionCmd& iCmd);

    void setStart(int x,int y);
    void setEnd(int x,int y);
    void setDirection(edouble angle);

private:
    std::vector<cv::Point> vPathList;
    cv::Point m_iCurPos;
    edouble   m_dLastDirection;
    edouble   m_dGlobalDirection;

    cv::Point sStartPoint;
    cv::Point sEndPoint;

//    vector<CWheelGoToPositionCmd> vCmd;
};

#endif // MOVETRAJ_H
