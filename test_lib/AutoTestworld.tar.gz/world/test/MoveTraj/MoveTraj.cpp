#include "MoveTraj.h"

MoveTraj::MoveTraj()
{
    m_dGlobalDirection = 0;

    sStartPoint.x = zero_X;
    sStartPoint.y = zero_Y;
    sEndPoint.x = goal_X;
    sEndPoint.y = goal_Y;

}

void MoveTraj::getMoveTraj(vector<CWheelGoToPositionCmd> &vCmd , cv::Mat &iMap)
{
    cv::Mat iCell;
    cv::Mat iExpanded;

    //读取图片
    iMap = cv::imread("../map.png",CV_LOAD_IMAGE_GRAYSCALE);

    if(iMap.empty())
    {
        std::cout<<"map is empty!!!"<<std::endl;
        return ;
    }

    //将图片信息转成地图信息
    ImageTool::MapToCell(iMap,iCell);

    // 膨胀地图
    iExpanded = iCell;
    MapExpand::ExpandMap(iCell,iExpanded);

    //开始AStar规划
    vPathList.clear();
    vPathList.push_back(sStartPoint);
    vPathList.push_back(sEndPoint);
    AStar::GetTrajectory(iExpanded,vPathList);


    if(vPathList.empty()){
        return;
    }

    //提取拐点
    MergeTraj::Merge(vPathList);
    for(eint n=0;n<vPathList.size()-1;n++)
    {
        ImageTool::DrawLine(iMap,vPathList[n],vPathList[n+1]);
    }


    //move

    while(1)
    {
        if(abs(sStartPoint.x - vPathList[0].x)<1 && abs(sStartPoint.y-vPathList[0].y)<1){
            m_iCurPos = vPathList[0];
            vPathList.erase(vPathList.begin());
        }
        else
            break;
    }

    int size = vPathList.size();
    for(eint n=0;n<size;n++)
    {
        CWheelGoToPositionCmd iCmd;
        GetMoveCommand(iCmd);
        vCmd.push_back(iCmd);
        m_dLastDirection = iCmd.m_fRelativeTheta;
        m_dGlobalDirection += m_dLastDirection;
         m_iCurPos = vPathList[0];
        vPathList.erase(vPathList.begin());
    }
}


eint MoveTraj::GetMoveCommand(CWheelGoToPositionCmd& iCmd)
{
    double dTmpX,dTmpY;
    dTmpX = (efloat)(vPathList[0].y-m_iCurPos.y)*1;//根据比例调整
    dTmpY = (efloat)(vPathList[0].x-m_iCurPos.x)*1;//根据比例调整
    iCmd.m_fRelativeX = cos(-m_dGlobalDirection)*dTmpX-sin(-m_dGlobalDirection)*dTmpY; //计算X方向增量指令
    iCmd.m_fRelativeY = sin(-m_dGlobalDirection)*dTmpX+cos(-m_dGlobalDirection)*dTmpY;//计算Y方向增量指令
    //计算Theta方向增量指令
//    if(0==double(iCmd.m_fRelativeX))
    if(0==iCmd.m_fRelativeX){
        iCmd.m_fRelativeTheta = iCmd.m_fRelativeY>0?1.57:-1.57;
    }
    else{
        iCmd.m_fRelativeTheta = atan(iCmd.m_fRelativeY/iCmd.m_fRelativeX);
    }


    if(0> iCmd.m_fRelativeX){
        if(0>iCmd.m_fRelativeY){
             iCmd.m_fRelativeTheta =   (-3.14) + iCmd.m_fRelativeTheta;
        }else{
             iCmd.m_fRelativeTheta = 3.14 - iCmd.m_fRelativeTheta ;
        }


    }

    iCmd.m_fSpeed = 0.5;
    return ERR_NONE;
}



void MoveTraj::setStart(int x,int y){

    sStartPoint.x = y + zero_X;
    sStartPoint.y = x + zero_Y;

}

void MoveTraj::setEnd(int x,int y){
    sEndPoint.x =  y + zero_X;
    sEndPoint.y = x + zero_Y;
}

void MoveTraj::setDirection(edouble angle){
      m_dGlobalDirection = angle;
}

