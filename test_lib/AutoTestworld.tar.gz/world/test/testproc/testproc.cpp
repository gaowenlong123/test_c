#include "testproc.h"
#include <EwayFunc/FuncInterface.h>
#include <iostream>
using namespace std;

Declare_FunSdk_Lib(testproc)
Declare_Function_ID("cf18bd86-988c-43b5-88ac-f8b268ba6ac7")
Declare_Function_Priority(FunPri_Normal)

RegisterMessage_Start
RegisterMessage_End

BEGIN_FIFEMSG_MAP(testproc,CFuncInterface)
//MSG_FIFMAP(FunMsg_User+1,OnMessageProcess)
END_FIFMSG_MAP
#include <opencv/cv.hpp>
testproc::testproc()
{
}

testproc::~testproc()
{
}

eint testproc::Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut)
{
    bLimbAuthority = true;

    vFeatureList.push_back(SysCom_ID_LMsg_RobPos);

    vFeatureList.push_back(SysCom_ID_LMsg_Sonar);
    vFeatureList.push_back(SysCom_ID_LMsg_Laser);
    vFeatureList.push_back(SysCom_ID_Vision_Marker);

    dTimeOut = 5;

    isReadyTest = false;
    m_bTestDone = false;
    isTestOver = false;

    return ERR_NONE;
}
eint testproc::Destroy()
{
    return ERR_NONE;
}
eint testproc::CheckMsgCode(eint nMsgCode)
{
//    if( nMsgCode ==  SysCom_ID_LMsg_RobPos){

//        return MsgProcCode_Record;

//    }else if (nMsgCode == SysCom_ID_LMsg_Sonar ) {

//            return MsgProcCode_Notify;

//    }else if (nMsgCode == SysCom_ID_LMsg_Laser ) {

//            return MsgProcCode_Notify;

//    }else if (nMsgCode == SysCom_ID_Vision_Marker ) {

//            return MsgProcCode_Notify;
//    }

    return MsgProcCode_Notify;
}

void testproc::JobStart()
{


    SetTimer(200);

    Move(0,MARKER);

    eint nLoadResult = AddChildFun ("autotestlib", &gGuid, "x=10;y=0");

    if(ERR_NONE != nLoadResult)
    {
        OSG_WriteLog (LogError, "加载子Function出错，错误值：%d", nLoadResult);
    }

    return ;
}

void testproc::JobFailed(eint nErrCode)
{
    return ;
}


eint testproc::ProcTimer(edouble dTimeStamp)
{
    if(isReadyTest && m_bTestDone && !isTestOver)
    {

        switch(m_nStage)
        {
        case Stage_Init:
        {
            m_bTestDone = false;
            isReadyTest = false;
            eint nLoadResult = AddChildFun ("autotestlib", &gGuid, "x=0;y=0");
            isTestOver = true;
        }
            break;
        case Stage_Sonar:
        {
             m_bTestDone = false;
            Move(1.57,SONAR);
        }
            break;
        case Stage_Laser:
        {
             m_bTestDone = false;
             Move(1.57,LASER);
        }
            break;
        case Stage_Marker:
        {
             m_bTestDone = false;
            Move(0,MARKER);
        }
            break;
        case Stage_End:
        {
            m_bTestDone =  false;
            Move(0,2.5,1.57,End);
            std::cout<<"test End"<<std::endl;
        }
            break;

        }

    }
    return 0;
}

void testproc::Move(edouble angle ,typefeature _type)
{
    m_bCmdDone = true;
    while(1){
        if(GetMsgData(&CurrentRobPos)){
            if(0.17<abs(CurrentRobPos.m_dRZ - angle))
            {
                m_bCmdDone = false;
                SendWheelCycle(angle - CurrentRobPos.m_dRZ  , 0,0.5,m_nCmdSN);

            }

            break;
        }
    }

    edouble temp = ewayos::Time::GetSystemTime();
    while(1){
        if(m_bCmdDone){
            for(int i=0;i<5;i++){
                OutPut(_type);
            }
            break;
        }

        if(5<ewayos::Time::GetSystemTime()-temp)
        {
            m_bCmdDone = true;
            ewayos::Time::Sleep(4000);
        }
    }

    m_bTestDone = true;

}

void testproc::Move(edouble dx,edouble dy ,edouble angle ,typefeature _type)
{
    m_bCmdDone = true;
    while(1){
        if(GetMsgData(&CurrentRobPos)){
            if(0.17>abs(CurrentRobPos.m_dRZ - angle))
            {
                m_bCmdDone = false;
                SendWheelGoToPosition(dx,dy,angle,0.5,m_nCmdSN);

            }else{
                SendWheelGoToPosition(dx,dy,angle - CurrentRobPos.m_dRZ ,0.5,m_nCmdSN);
            }

            break;
        }
    }

    edouble temp = ewayos::Time::GetSystemTime();
    while(1){
        if(m_bCmdDone){
            for(int i=0;i<5;i++){
                OutPut(_type);
            }
            break;
        }

        if(5<ewayos::Time::GetSystemTime()-temp)
        {
            m_bCmdDone = true;
            ewayos::Time::Sleep(10000);
        }
    }

    m_bTestDone = true;

}

eint testproc::ProcChildFunQuit(edouble dTimeStamp,EGUID* pgFunID,eint nRetCode,std::string& iRetStr)
{
    if(nRetCode == 1){
        if(isReadyTest){
            m_nStage = Stage_End;
            m_bTestDone = true;
        }else{

            m_nStage = Stage_Sonar;
            isReadyTest = true;
            m_bTestDone = true;
        }
    }

}

eint testproc::ProcMotCmdDone(edouble dTimeStamp,CCmdDoneMessage* piCmdDone)
{
//    &&m_nCmdSN == piCmdDone->m_nCmdSN
//    if(!m_bCmdDone)
//    {
//        switch(m_nStage)
//        {
//        case Stage_Sonar:
//        {
//            m_bCmdDone = true;
//            m_nStage = Stage_Laser;
//        }
//            break;
//        case Stage_Laser:
//        {
//            m_bCmdDone = true;
//            m_nStage = Stage_Marker;
//        }
//            break;
//        case Stage_Marker:
//        {
//            m_bCmdDone = true;
//            m_nStage = Stage_End;
//        }
//            break;
//        }
//    }
}



void testproc::OutPut(typefeature _type){

    if(_type==SONAR){
        CSonarMessage info ;
         GetMsgData(&info);
         for(int i= 0; i<info.m_vInfoList.size();i++)
         {
             std::cout<<"ID:"<<i+1<<"dis:"<<info.m_vInfoList[i].m_dObstacleDistance<<std::endl;
         }
         m_nStage = Stage_Laser;

    }else if(_type == MARKER)
    {
        CMarkerMessage info ;
        GetMsgData(&info);
        std::cout<<"Marker Info"<<std::endl;
        for(int i =0 ;i<info.m_vMarkerList.size();i++){
            std::cout<<"ID:"<<info.m_vMarkerList[i].m_nID
                    <<"m_dX:"<<info.m_vMarkerList[i].m_dX
                   <<"m_dY:"<<info.m_vMarkerList[i].m_dY
                     <<"m_dZ:"<<info.m_vMarkerList[i].m_dZ
                   <<std::endl;
        }
        m_nStage = Stage_Sonar;
    }
    else if(_type == LASER){
        CLaserScanMessage info ;
        GetMsgData(&info);

        for(int i=0;i<=10;i++){
            std::cout<<"Angle:"<<info.m_viLaserScanInfoList[175+i].m_dAngle<<"dis:"<<info.m_viLaserScanInfoList[175+i].m_dDistance<<std::endl;
        }

        m_nStage = Stage_End;
    }
    else{
         m_nStage = Stage_Init;
    }

}

ebool testproc::IsArrived(CBotPosMessage& RobPos)
{
//    if( RobPos.m_dX > GoalPos.m_dX-0.2 &&  RobPos.m_dX<GoalPos.m_dX + 0.2
//            && RobPos.m_dY > GoalPos.m_dY- 0.2 &&  RobPos.m_dY<GoalPos.m_dY + 0.2){
//        return true;
//    }

    return false;
}

eint testproc::ProcVisionMarker(edouble dTimeStamp,CMarkerMessage* piMarkerList)
{

}

eint testproc::ProcSonarMsg(edouble dTimeStamp,CSonarMessage* piSonarMsg)
{

}

eint testproc::ProcLaserMsg(edouble dTimeStamp,CLaserScanMessage* piMsg)
{

}

