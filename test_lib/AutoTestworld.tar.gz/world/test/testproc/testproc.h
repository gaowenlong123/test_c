#ifndef testproc_H
#define testproc_H

#include <EwayFunc/FuncInterface.h>
#include <opencv/cv.hpp>
Declare_FunLibSymble

enum typefeature{
    SONAR,
    LASER,
    MARKER,
    End,
};

#define Stage_Init  0
#define Stage_Sonar 1
#define Stage_Laser 2
#define Stage_Marker 3
#define Stage_End 10

class testproc:public CFuncInterface
{
public:
   testproc();
   virtual ~testproc();
   virtual eint Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut);
   virtual eint Destroy();
   virtual eint CheckMsgCode(eint nMsgCode);
   
   virtual void JobStart();
   virtual void JobFailed(eint nErrCode);


   virtual eint ProcTimer(edouble dTimeStamp);
   virtual eint ProcVisionMarker(edouble dTimeStamp,CMarkerMessage* piMarkerList);
   virtual eint ProcMotCmdDone(edouble dTimeStamp,CCmdDoneMessage* piCmdDone);
   virtual eint ProcSonarMsg(edouble dTimeStamp,CSonarMessage* piSonarMsg);
   virtual eint ProcLaserMsg(edouble dTimeStamp,CLaserScanMessage* piMsg);

   virtual eint ProcChildFunQuit(edouble dTimeStamp,EGUID* pgFunID,eint nRetCode,std::string& iRetStr);

   virtual ebool IsArrived(CBotPosMessage& RobPos);

   void Move(edouble angle ,typefeature _type);
   void Move(edouble dx ,edouble dy,edouble angle ,typefeature _type);

   void OutPut( typefeature _type);
private:
    CBotPosMessage CurrentRobPos;
    EGUID gGuid;
    ebool isReadyTest;

    ebool m_bTestDone;
    ebool m_bCmdDone;
    eint m_nStage;
    euint m_nCmdSN;

    ebool isTestOver;

   DECLEAR_FIFMESSAGE_MAP
};

#endif // testproc_H
