#include <EwayFunc/FuncSdkLib.h>
#include "testproc.h"

int main()
{
   ewayos::FunctionRun("127.0.0.1","testproc",1);
   return 0;
}
