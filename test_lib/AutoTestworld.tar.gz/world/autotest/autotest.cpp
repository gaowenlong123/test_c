#include "autotest.h"
#include <iostream>
#include "ImageTool.h"
#include "MapExpand.h"
#include "MergeTraj.h"
#include "AStar.h"
#include <boost/algorithm/string/classification.hpp>
#include <boost/algorithm/string/split.hpp>

Declare_Sensor_Interface(autotest)
Declare_Element_ID("4dac5b31-2e48-48cd-8eb2-49b6b7477749")

//Declare_Feature_None
Declare_Feature_Code(90000, CAutoTestMessage)

Declare_Input_Pin_Start
//Declare_Input_Pin(1, "Input Pin Name",false,cvmatbridge)
Declare_Pin_End

Declare_Output_Pin_Start
//Declare_Output_Pin(1,"Output Pin Name")
Declare_Pin_End

Declare_Feedback_Start
//Declare_Feedback("Feedback Name")
Declare_FeedBack_End


autotest::autotest()
{
}

autotest::~autotest()
{
}

void autotest::Initialize()
{

    std::cout<<"Initialize"<<std::endl;
    vCmd.clear();
    vPathList.clear();

    m_pThread = (CEBaseThread*)EwayOS_Thread_GetThreadInstance();

    cv::Mat iCell;
    //读取图片
    iMap = cv::imread("/usr/share/ewaybot/simulation/lib/sensor/SimulationElem/autotest/map.png",CV_LOAD_IMAGE_GRAYSCALE);

    if(iMap.empty())
    {
        std::cout<<"map is empty!!!"<<std::endl;
        return ;
    }

    //将图片信息转成地图信息
    ImageTool::MapToCell(iMap,iCell);

    // 膨胀地图
    iExpanded = iCell;
    MapExpand::ExpandMap(iCell,iExpanded);

}

void autotest::Destroy()
{
     m_pThread->WaitForThreadQuit();
}

void autotest::ProcFeatureEnabled(ebool bEnableFlag,estring* psParam)
{
    if(!bEnableFlag){
        return ;
    }

    std::cout<<"ProcFeatureEnabled"<<std::endl;

    if(0>SetParam(*psParam)){
        std::cout<<"set param failed"<<std::endl;
        return ;
    }

    if(0>GetTraj()){
         std::cout<<"规划 failed"<<std::endl;
         return ;
    }

    //show map
    m_pThread->CreateThread(autotest::ThreadProc,(eint)this);

    //move
    while(1)
    {
        if(abs(sStartPoint.x - vPathList[0].x)<1 && abs(sStartPoint.y-vPathList[0].y)<1){
            m_iCurPos = vPathList[0];
            vPathList.erase(vPathList.begin());
        }
        else
            break;
    }

    int size = vPathList.size();

    CAutoTestMessage autotest;
    for(eint n=0;n<size;n++)
    {
        CWheelGoToPositionCmd iCmd;
        GetMoveCommand(iCmd);
        vCmd.push_back(iCmd);
        m_dLastDirection = iCmd.m_fRelativeTheta;
        m_dGlobalDirection += m_dLastDirection;
         m_iCurPos = vPathList[0];
        vPathList.erase(vPathList.begin());

        autotest.m_vIntList.push_back(size);
    }

//    autotest.m_vCmdList = vCmd;
//    SendUserMessage(&autotest);



    autotest.m_dPara  = 2000;
    SendUserMessage(&autotest);
}

eint autotest::SetParam(estring psParam)
{

        if(psParam=="")
        {
            string ch = "x=10;y=0";
            psParam = ch;
        }
    vector<string> vStr;
    boost::split( vStr, psParam, boost::is_any_of( "xX=;yY" ), boost::token_compress_on );
    for( vector<string>::iterator it = vStr.begin(); it != vStr.end(); ++ it )
    {
        if(*it=="")
            vStr.erase(it);
    }
    sEndPoint.x = atoi(vStr[1].c_str()) + zero_X;//y
    sEndPoint.y = atoi(vStr[0].c_str()) +  zero_Y;//x

    std::cout<<"endpoint X:"<<sEndPoint.x <<"endpoint Y:"<<sEndPoint.y <<std::endl;

    CBotPosMessage iPosMsg;
    while(true){
        if(GetRobotInfo(iPosMsg)){
            CurrentPos.m_dX = iPosMsg.m_dX;
            CurrentPos.m_dY = iPosMsg.m_dY;
            CurrentPos.m_RZ = iPosMsg.m_dRZ;
            if(iPosMsg.m_fLeftSpeed > -10000)
            {
                break;
            }

        }

    }

    m_dGlobalDirection = iPosMsg.m_dRZ;

    sStartPoint.x =(int)CurrentPos.m_dY + zero_X;
    sStartPoint.y =(int)CurrentPos.m_dX + zero_Y;

    std::cout<<"sStartPoint X:"<<sStartPoint.x <<"sStartPoint Y:"<<sStartPoint.y <<std::endl;

    return 0;
}

eint autotest::GetTraj()
{
    //开始AStar规划
    vPathList.clear();
    vPathList.push_back(sStartPoint);
    vPathList.push_back(sEndPoint);
    AStar::GetTrajectory(iExpanded,vPathList);


    if(vPathList.empty()){
        return -1;
    }

    //提取拐点
    MergeTraj::Merge(vPathList);
    for(eint n=0;n<vPathList.size()-1;n++)
    {
        ImageTool::DrawLine(iMap,vPathList[n],vPathList[n+1]);
    }

    return 0;

}

eint autotest::GetMoveCommand(CWheelGoToPositionCmd& iCmd)
{
    double dTmpX,dTmpY;
    dTmpX = (efloat)(vPathList[0].y-m_iCurPos.y)*1;//根据比例调整
    dTmpY = (efloat)(vPathList[0].x-m_iCurPos.x)*1;//根据比例调整
    iCmd.m_fRelativeX = cos(-m_dGlobalDirection)*dTmpX-sin(-m_dGlobalDirection)*dTmpY; //计算X方向增量指令
    iCmd.m_fRelativeY = sin(-m_dGlobalDirection)*dTmpX+cos(-m_dGlobalDirection)*dTmpY;//计算Y方向增量指令
    //计算Theta方向增量指令
//    if(0==double(iCmd.m_fRelativeX))
    if(0==iCmd.m_fRelativeX){
        iCmd.m_fRelativeTheta = iCmd.m_fRelativeY>0?1.57:-1.57;
    }
    else{
        iCmd.m_fRelativeTheta = atan(iCmd.m_fRelativeY/iCmd.m_fRelativeX);
    }


    if(0> iCmd.m_fRelativeX){
        if(0>iCmd.m_fRelativeY){
             iCmd.m_fRelativeTheta =   (-3.14) + iCmd.m_fRelativeTheta;
        }else{
             iCmd.m_fRelativeTheta = 3.14 - iCmd.m_fRelativeTheta ;
        }


    }

    iCmd.m_fSpeed = 0.5;
    return ERR_NONE;
}

void autotest::ThreadProc(eint nArgv)
{
    ((autotest*)nArgv)->ShowMap();
}

void autotest::ShowMap()
{
    cv::namedWindow("AStar",1);
    cv::imshow("AStar", iMap);
    cv::waitKey(400);

    cv::destroyWindow("AStar");

    std::cout<<"ThreadProc quit"<<std::endl;

    ewayos::Time::Sleep(3000);
    CAutoTestMessage dautotest;
    dautotest.m_dPara=1000;
    SendUserMessage(&dautotest);

}

void autotest::ProcPinDisabled(euint unPinID,euint unPinType)
{
}

void autotest::ProcPinEnabled(euint unPinID,euint unPinType)
{
}

void autotest::ProcInputData(std::vector<CPinDataWithID>& iDataList)
{

}

void autotest::ProcFeedbackData(CFeedbackData& iFeedbackData)
{
}

void autotest::ProcFeedbackData(echar* strFeedbackName, eint nParam)
{

}
