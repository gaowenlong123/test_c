#ifndef autotest_H
#define autotest_H

#include <EwaySensor/ElemInterface.h>
#include <EwayCore/Messages/autotestMessage.h>
#include <EwayFunc/FuncInterface.h>
#include <opencv/cv.hpp>
#define zero_X  30
#define zero_Y  10
#define goal_X  29
#define goal_Y  20


struct MapPostion{
    eint m_dX;
    eint m_dY;
    edouble m_RZ;
};


class autotest:public CElemInterface
{
public:
   autotest();
   virtual ~autotest();
   virtual void Initialize();
   virtual void Destroy();
   virtual void ProcFeatureEnabled(ebool bEnableFlag,estring* psParam);
   virtual void ProcPinDisabled(euint unPinID,euint unPinType);
   virtual void ProcPinEnabled(euint unPinID,euint unPinType);
   virtual void ProcInputData(std::vector<CPinDataWithID>& iDataList);
   virtual void ProcFeedbackData(CFeedbackData& iFeedbackData);
   virtual void ProcFeedbackData(echar* strFeedbackName, eint nParam);


protected:
   static void ThreadProc(eint nArgv);
   void ShowMap();
   eint GetMoveCommand(CWheelGoToPositionCmd& iCmd);

   eint GetTraj();
   eint SetParam(estring psParam);

private:
   std::vector<cv::Point> vPathList;
   vector<CWheelGoToPositionCmd> vCmd;

   cv::Point sStartPoint;
   cv::Point sEndPoint;
   edouble   m_dGlobalDirection;

   cv::Point m_iCurPos;
   edouble   m_dLastDirection;
   MapPostion CurrentPos;

   cv::Mat iMap;
   cv::Mat iExpanded;

   CEBaseThread* m_pThread;
};

#endif // autotest_H
