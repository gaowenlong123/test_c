#ifndef ASTAR_H
#define ASTAR_H

#include "ImageTool.h"
using namespace std;
class AStar
{
public:
    struct Node
    {
        int m_nx,m_ny; // 结点在地图上的坐标
        int m_nF,m_nG,m_nH;// 结点的F\G\H值
        Node *m_pParent;// 结点的父结点
        Node(int nx, int ny) :m_nx(nx), m_ny(ny), m_nF(0), m_nG(0), m_nH(0), m_pParent(NULL) {}  //变量初始化
    };
    AStar(){}
    static void GetTrajectory(cv::Mat& iMap,std::vector<cv::Point>& vPathList);
    void Init(vector<vector<int> > &vMap);            //初始化图
    std::vector<std::vector<int> > GetMap();//获取地图
    Node* FindStartNode(); //寻找开始点
    Node* FindEndNode(); //寻找终止点
    vector<Node *> GetPath(Node &iStartNode, Node &iEndNode);//获得最短的路径
    static Node* FindPath(Node &iStartNode, Node &iEndNode);//找最短的路径


//private:
    static cv::Mat m_iMap;     //存放地图
    static vector<Node *> m_vOpenList;     //开集
    static vector<Node *> m_vCloseList;    //闭集

    static vector<Node *> GetSurroundNodes(const Node *piCurrentNode) ;//遍历当前点的周围点
    static bool IsReachable(const Node *piCurrentNode, const Node *piTargetNode) ; //判断某点是否可以用于下一步判断
    static bool IsInList(const vector<Node *> &vList,const Node *piNode) ; //判断开/闭列表中是否包含某点
    static void DeleteNode(vector<Node *> &vList,Node *piNode); //删除点
    static Node *GetLeastFNode(); //从开列表中返回F值最小的节点
    static int CalcG(Node *piNode);//计算G值
    static int CalcH(Node *piNode, Node iEndNode);//计算H值
};

#endif // ASTAR_H
