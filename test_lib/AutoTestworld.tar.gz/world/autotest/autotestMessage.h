/*  版权所有 (c) 2017 - 2022,北京一维弦科技有限责任公司.著作人保留所有权利.

        本文件包含部分Ewaybot Operating System(EwayOS)代码,其中包含:
        一帧图像中包含的所有人脸，物体或数字的分类消息及置信度.

        本段代码为开源代码,在遵守BSD 2-Clause License的前提下，开发者可再
        发布软件或以源代码及二进制形式使用软件，包括进行修改或不进行修改.

        北京一维弦科技有限公司,北京市海淀区北三环西路48号北京科技会展中心1B座16L*/

#ifndef CAUTOTESTMESSAGE_H
#define CAUTOTESTMESSAGE_H
#include "PredictInfo.h"

class CAutoTestMessage : public CBaseMessage
{
public:
    CAutoTestMessage()
    {
        Clear();
    }

    virtual ~CAutoTestMessage(){}

    // 一帧图像中包含的所有识别信息
    std::vector<CWheelGoToPositionCmd> m_vCmdList;

    /************************* compare obj start *************************/
    virtual ebool operator == (const CEwayData& iSrc)
    {
        const CAutoTestMessage* piSrc = dynamic_cast<const CAutoTestMessage*>(&iSrc);
        if(NULL==piSrc)
            return false;
        return this->operator==(*piSrc);
    }
    virtual ebool operator == (const CBaseMessage& iSrc)
    {
        const CAutoTestMessage* piSrc = dynamic_cast<const CAutoTestMessage*>(&iSrc);
        if(NULL==piSrc)
            return false;
        return this->operator==(*piSrc);
    }
    virtual ebool operator == (const CAutoTestMessage& iSrc)
    {

        if(iSrc.m_nPriority == m_nPriority &&
                iSrc.m_nMessageCode == m_nMessageCode &&
                iSrc.m_vCmdList.size() == m_vCmdList.size()
                )
            return true;
        else
            return false;
    }
    /************************* Compare Obj End *************************/


    /************************* overload operator start *************************/
    virtual CEwayData& operator = (const CEwayData& iMsg)
    {
        *this = (CAutoTestMessage&)iMsg;
        return *this;
    }
    virtual CBaseMessage& operator = (const CBaseMessage& iMsg)
    {
        *this = (CAutoTestMessage&)iMsg;
        return *this;
    }
    virtual CAutoTestMessage& operator = (const CAutoTestMessage& iMsg)
    {
        m_dTimeStamp = iMsg.m_dTimeStamp;
        m_nPriority = iMsg.m_nPriority;
        m_nMessageCode = iMsg.m_nMessageCode;
        m_vCmdList = iMsg.m_vCmdList;
        return *this;
    }

    /************************* overload operator end *************************/


    /************************* Serilize & Deserilize  start *************************/
    /**
        * @brief Serilize  序列化
        * @param pBuf	输入buffer
        * @param nBufLen	buffer 长度
        * @param nWriteLen
        * @return 实际序列化buffer的长度，-1 输入buffer长度不足,需要buffer长度为 nWriteLen
        */
    virtual eint Serilize(  euint8* pBuf,euint nBufLen,euint& nWriteLen)
    {
        nWriteLen=0;
        eint32 nVectorLength=0,nPos=0;
        nVectorLength=m_vCmdList.size();
        euint nPackLen = sizeof(eint32);

        CBaseMessage::Serilize(pBuf,0,nWriteLen);
        nPackLen += nWriteLen;

        for(eint n=0;n<nVectorLength;n++)
        {
            if(BUFFER_NOT_ENOUGH==m_vCmdList[n].Serilize(pBuf,0,nWriteLen))
                nPackLen += nWriteLen;
        }

        if(nullptr==pBuf||nBufLen< nPackLen)
        {
            nWriteLen = nPackLen;
            return BUFFER_NOT_ENOUGH;
        }
        CBaseMessage::Serilize(pBuf,nBufLen,nWriteLen);
        nPos = nWriteLen;
        nPos = MemM_FillMemory((void*)pBuf,(const void*)&nVectorLength,sizeof(eint32),nPos);
        for(eint i=0;i<nVectorLength;i++)
        {
            m_vCmdList[i].Serilize(pBuf+nPos,nBufLen-nPos,nWriteLen);
            nPos += nWriteLen;
        }
        nWriteLen = nPos;
        return ERR_NONE;
    }
    /**
        * @brief Deserilize  反序列化
        * @param pBuf	输入buffer
        * @param nLength	buffer 长度
        * @param nReadLen
        * @return 实际反序列化buffer的长度，-1 输入buffer长度不足,需要buffer长度为 nReadLen
        */
    virtual eint Deserilize( const euint8* pBuf,euint nLength,euint& nReadLen)
    {
        nReadLen = 0;
        eint32 nPos=0;
        eint32 nVectorLength = 0;
        euint nPackLen =   sizeof(eint32);
        CBaseMessage::Deserilize( pBuf,0,nReadLen);
        nPackLen += nReadLen;
        Clear();
        if(nLength<nPackLen)
        {
            nReadLen = nPackLen;
            return BUFFER_NOT_ENOUGH;
        }
        CBaseMessage::Deserilize(pBuf,nLength,nReadLen);
        nPos = nReadLen;
        nPos = MemM_GetDataFromMem(pBuf, &nVectorLength, sizeof(eint32), nPos);

        m_vCmdList.resize(nVectorLength);
        for(eint i=0;i<nVectorLength;i++)
        {
            if(m_vCmdList[i].Deserilize(pBuf+nPos,nLength-nPos,nReadLen) == BUFFER_NOT_ENOUGH)
            {
                nPackLen += nReadLen;
                nReadLen = nPackLen;
                return BUFFER_NOT_ENOUGH;
            }
            nPos += nReadLen;
        }
        nReadLen = nPos;
        return ERR_NONE;
    }
    /************************* Serilize & Deserilize  end *************************/


    //deepCopy
    virtual CEwayData* Duplicate(const CEwayData* piSrc){
        CAutoTestMessage* piNewInst = NULL;
        const CAutoTestMessage* piCV = dynamic_cast<const CAutoTestMessage*>(piSrc);
        if(NULL==piCV)
            return NULL;
        piNewInst = new CAutoTestMessage;
        *piNewInst = *piCV;
        return piNewInst;
    }

    virtual void Clear()
    {
        CBaseMessage::Clear();
        m_vCmdList.clear();

    }
protected:

private:


};

#endif //  CAUTOTESTMESSAGE_H
