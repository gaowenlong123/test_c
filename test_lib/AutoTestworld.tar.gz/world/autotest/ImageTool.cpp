#include "ImageTool.h"
#include "iostream"
#include <opencv/cv.hpp>



void  ImageTool::DrawLine(cv::Mat &iMap, cv::Point &sStart, cv::Point &sEnd)
{
    cv::Point sPoint ;

    edouble dX=0,dY=0;
    euint nCount = sqrt(pow((sEnd.x - sStart.x),2) + pow((sEnd.y - sStart.y),2));

    edouble dXStep = (edouble)(sEnd.x - sStart.x)/nCount;
    edouble dYStep = (edouble)(sEnd.y - sStart.y)/nCount;

    for(euint n=0 ; n<nCount +1 ; n++){
        dX = sStart.x + (dXStep*(edouble)n+0.5);
        sPoint.x  = dX;
        dY = sStart.y + (dYStep*(edouble)n+0.5);
        sPoint.y  = dY;
        DrawCell(iMap ,sPoint);
    }

}


void ImageTool::DrawCell(cv::Mat &iMap, cv::Point &sPoint, cv::Scalar sColor){
    cv::Rect sRect;
    sRect.x = sPoint.x*11;
    sRect.y = sPoint.y*11;
    sRect.width = 11;
    sRect.height = 11;
    cv::rectangle(iMap, sRect,sColor,CV_FILLED);
    return;

}


void ImageTool::MapToCell(cv::Mat &iMap, cv::Mat &iCell)
{
//    iCell.create(29,32,CV_8UC1);
//    for(euint n=0;n<29;n++)
//    {
//        for(euint m=0;m<32;m++)
//        {
//            iCell.at<uchar>(n, m) = iMap.at<uchar>(n*11+5,m*11+5)<128?0:255;
//        }
//    }

    iCell.create(RowsCell,ColsCell,CV_8UC1);
    for(euint n=0;n<RowsCell;n++)
    {
        for(euint m=0;m<ColsCell;m++)
        {
            iCell.at<uchar>(n, m) = iMap.at<uchar>(n*(CellSize+1) + 5, m*(CellSize+1) + 5) <128?0:255;
        }
    }
}

void ImageTool::SaveMap(cv::Mat &iMap)
{
    iMap.create(Rows, Cols,CV_8UC1);

    cv::Point o;
    o.x = 30*11;
    o.y = 10*11;

    for(euint n =0 ; n < Rows ;n++){

        for(euint m =0 ; m < Cols ;m++){

            iMap.at<uchar>(n, m) = 255;

            if(n>20*11 && 20*11<m && m<40*11 ){
                iMap.at<uchar>(n, m) = 0;
            }

            if(n>20*11&& n<25*11 && 28*11<m && m<32*11 ){
                iMap.at<uchar>(n, m) = 255;
            }


            if(n%11 == 0 || m%11 ==0){

                iMap.at<uchar>(n, m) = 0;
            }


        }
    }

       cv::circle(iMap,o,3,cv::Scalar(0,0,0),-1);

       cv::imwrite("./aa.png",iMap);

}
