#ifndef IMAGETOOL_H
#define IMAGETOOL_H

#include <opencv/cv.hpp>
#include "EwayCore/EwaySdkDefine.h"
#define ColsCell 60
#define RowsCell 30
#define CellSize 10
#define LineSize 1

#define Cols  ColsCell*CellSize + ColsCell*LineSize
#define Rows  RowsCell*CellSize + + RowsCell*LineSize

class ImageTool
{

public:
    ImageTool(){}

    static void DrawLine(cv::Mat& iMap,cv::Point& sStart , cv::Point& sEnd);
    static void DrawCell(cv::Mat& iMap, cv::Point& sPoint, cv::Scalar sColor=cv::Scalar(128,128,128));
    static void MapToCell(cv::Mat& iMap ,cv::Mat& icell);

    static void SaveMap(cv::Mat& iMap);

private:

};

#endif // IMAGETOOL_H
