#include "autotestlib.h"
#include <EwayFunc/FuncSdkLib.h>
#include <iostream>
#include "ImageTool.h"
#include "MapExpand.h"
#include "MergeTraj.h"
#include "AStar.h"
#include <boost/algorithm/string/classification.hpp>
#include <boost/algorithm/string/split.hpp>


Declare_FunSdk_Lib(autotestlib)
Declare_Function_ID("49af0903-5c65-4d23-874e-9e43fdda21dc")
Declare_Function_Priority(FunPri_Normal)

RegisterMessage_Start
RegisterMessage_End

BEGIN_FIFEMSG_MAP(autotestlib,CFuncInterface)
//MSG_FIFMAP(FunMsg_User+1,OnMessageProcess)
END_FIFMSG_MAP

autotestlib::autotestlib()
{

}

autotestlib::~autotestlib()
{
}

eint autotestlib::Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut)
{
    std::cout<<"Initialize"<<std::endl;
    vCmd.clear();
    vPathList.clear();
    isRun = false;
    isArrived = false;

//    m_pThread = (CEBaseThread*)EwayOS_Thread_GetThreadInstance();

    bLimbAuthority = true;

    return ERR_NONE;
}
eint autotestlib::Destroy()
{
//    m_pThread->WaitForThreadQuit();
    return ERR_NONE;
}
eint autotestlib::CheckMsgCode(eint nMsgCode)
{
    return MsgProcCode_Record;
}

eint autotestlib::ProcSetFunParam(CSetParaMessage* piMsg)
{

    std::cout<<piMsg->m_strPara<<std::endl;

    getInit();

    if(0>SetParam(piMsg->m_strPara)){
        std::cout<<"set param failed"<<std::endl;
         FunQuit(0);;
    }

    if(0>GetTraj()){
         std::cout<<"规划 failed"<<std::endl;
          FunQuit(0);
    }

    //show map
//    m_pThread->CreateThread(autotestlib::ThreadProc,(eint)this);


    return ERR_NONE;
}

void autotestlib::getInit(){
    cv::Mat iCell;
    //读取图片
    iMap = cv::imread("/home/moro/Documents/world/autotestlib/map.png",CV_LOAD_IMAGE_GRAYSCALE);

    if(iMap.empty())
    {
        std::cout<<"map is empty!!!"<<std::endl;
        FunQuit(0);
    }

    //将图片信息转成地图信息
    ImageTool::MapToCell(iMap,iCell);

    // 膨胀地图
    iExpanded = iCell;
    MapExpand::ExpandMap(iCell,iExpanded);
}

void autotestlib::JobStart()
{

    std::cout<<"JobStart"<<std::endl;
    SetTimer(300);
    return ;
}

eint autotestlib::SetParam(estring psParam)
{
    vector<string> vStr;
    boost::split( vStr, psParam, boost::is_any_of( "xX=;yY" ), boost::token_compress_on );
    for( vector<string>::iterator it = vStr.begin(); it != vStr.end(); ++ it )
    {
        if(*it=="")
            vStr.erase(it);
    }
    sEndPoint.x = atoi(vStr[1].c_str()) + zero_X;//y
    sEndPoint.y = atoi(vStr[0].c_str()) +  zero_Y;//x

    std::cout<<"endpoint X:"<<sEndPoint.x <<"endpoint Y:"<<sEndPoint.y <<std::endl;

    CBotPosMessage iPosMsg;
    while(true){
        if(GetMsgData(&iPosMsg)){
            CurrentPos.m_dX = iPosMsg.m_dX;
            CurrentPos.m_dY = iPosMsg.m_dY;
            CurrentPos.m_RZ = iPosMsg.m_dRZ;
            if(iPosMsg.m_fLeftSpeed > -10000)
            {
                break;
            }

        }

    }

    m_dGlobalDirection = iPosMsg.m_dRZ;

    sStartPoint.x =(int)CurrentPos.m_dY + zero_X;
    sStartPoint.y =(int)CurrentPos.m_dX + zero_Y;

    std::cout<<"sStartPoint X:"<<sStartPoint.x <<"sStartPoint Y:"<<sStartPoint.y <<std::endl;

    return 0;
}

eint autotestlib::GetTraj()
{
    //开始AStar规划
    vPathList.clear();
    vPathList.push_back(sStartPoint);
    vPathList.push_back(sEndPoint);
    AStar::GetTrajectory(iExpanded,vPathList);

    std::cout<<"vPathList size ="<<vPathList.size()<<std::endl;
    if(vPathList.empty()){

        return -1;
    }

    //提取拐点
    MergeTraj::Merge(vPathList);
    for(eint n=0;n<vPathList.size()-1;n++)
    {
        ImageTool::DrawLine(iMap,vPathList[n],vPathList[n+1]);
    }

    return 0;

}

eint autotestlib::GetMoveCommand(CWheelGoToPositionCmd& iCmd)
{
    double dTmpX,dTmpY;
    dTmpX = (efloat)(vPathList[0].y-m_iCurPos.y)*1;//根据比例调整
    dTmpY = (efloat)(vPathList[0].x-m_iCurPos.x)*1;//根据比例调整
    iCmd.m_fRelativeX = cos(-m_dGlobalDirection)*dTmpX-sin(-m_dGlobalDirection)*dTmpY; //计算X方向增量指令
    iCmd.m_fRelativeY = sin(-m_dGlobalDirection)*dTmpX+cos(-m_dGlobalDirection)*dTmpY;//计算Y方向增量指令
    //计算Theta方向增量指令
//    if(0==double(iCmd.m_fRelativeX))
    if(0==iCmd.m_fRelativeX){
        iCmd.m_fRelativeTheta = iCmd.m_fRelativeY>0?1.57:-1.57;
    }
    else{
        iCmd.m_fRelativeTheta = atan(iCmd.m_fRelativeY/iCmd.m_fRelativeX);
    }


    if(0> iCmd.m_fRelativeX){
        if(0>iCmd.m_fRelativeY){
             iCmd.m_fRelativeTheta =   (-3.14) + iCmd.m_fRelativeTheta;
        }else{
             iCmd.m_fRelativeTheta = 3.14 - iCmd.m_fRelativeTheta ;
        }


    }

    iCmd.m_fSpeed = 0.5;
    return ERR_NONE;
}

void autotestlib::ThreadProc(eint nArgv)
{
    ((autotestlib*)nArgv)->ShowMap();
}

void autotestlib::ShowMap()
{
    cv::namedWindow("AStar",1);
    cv::imshow("AStar", iMap);
    cv::waitKey(400);

    cv::destroyWindow("AStar");

    std::cout<<"ThreadProc quit"<<std::endl;

}


void autotestlib::SendMove()
{
    if(vCmd.size()==0){
        isArrived = true;
        return;
    }

    SendWheelGoToPosition(vCmd[0].m_fRelativeX,vCmd[0].m_fRelativeY,vCmd[0].m_fRelativeTheta,vCmd[0].m_fSpeed,m_nCmdSN);//调用第一个坐标
    vCmd.erase(vCmd.begin());
}

eint autotestlib::ProcMotCmdDone(edouble dTimeStamp,CCmdDoneMessage* piCmdDone)
{
    if(m_nCmdSN==piCmdDone->m_nCmdSN && piCmdDone->m_nCmdID == SysCom_ID_LCmd_WheelGotoPos){
        SendMove();
    }

}

eint autotestlib::ProcTimer(edouble dTimeStamp)
{

    //move
    if(!isRun){
        isRun = true;
        while(1)
        {
            if(abs(sStartPoint.x - vPathList[0].x)<1 && abs(sStartPoint.y-vPathList[0].y)<1){
                m_iCurPos = vPathList[0];
                vPathList.erase(vPathList.begin());
            }
            else
                break;
        }

        int size = vPathList.size();

        for(eint n=0;n<size;n++)
        {
            CWheelGoToPositionCmd iCmd;
            GetMoveCommand(iCmd);
            vCmd.push_back(iCmd);
            m_dLastDirection = iCmd.m_fRelativeTheta;
            m_dGlobalDirection += m_dLastDirection;
            m_iCurPos = vPathList[0];
            vPathList.erase(vPathList.begin());
        }

        SendMove();
    }


    if(isRun&&isArrived){
        FunQuit(1);
    }
}

void autotestlib::JobFailed(eint nErrCode)
{
    return ;
}

