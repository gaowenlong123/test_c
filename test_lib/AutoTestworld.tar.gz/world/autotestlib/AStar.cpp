#include "AStar.h"
#include  "iostream"

#include<cmath>
using namespace std;
cv::Mat AStar::m_iMap = cv::Mat();
vector<AStar::Node *> AStar::m_vOpenList ={};     //开集
vector<AStar::Node *> AStar::m_vCloseList = {};    //闭集
/**
 * @brief AStar::IsInList 判断点Node是否在列表中
 * @param vList 节点列表
 * @param piNode    节点
 * @return  是否节点在列表里
 */
bool AStar::IsInList(const vector<Node *> &vList,const Node *piNode)
{
    //遍历闭列表,判断坐标是否相等
    for (Node* p : vList)
        if (p->m_nx == piNode->m_nx && p->m_ny == piNode->m_ny)
        {
            return true;
        }
    return false;
}


/**
 * @brief AStar::IsReachable  判断该点是否能到达
 * @param piCurrentNode 当前节点
 * @param piTargetNode  目标节点
 * @return  是否可到达
 */
bool AStar::IsReachable(const Node *piCurrentNode, const Node *piTargetNode)
{
    //如果点超出地图、不是上下左右、是障碍物、或者在闭列表中，返回false。反之。
    if (piTargetNode->m_nx < 0 || piTargetNode->m_nx > (int)(m_iMap.cols - 1)
        || piTargetNode->m_ny < 0 || piTargetNode->m_ny > (int)(m_iMap.rows - 1)
        || (int)m_iMap.at<uchar>(piTargetNode->m_ny,piTargetNode->m_nx)== 0
        || IsInList(m_vCloseList, piTargetNode))
        return false;
    else
        return true;
}

/**
 * @brief AStar::GetSurroundNodes   获取当前点的有效邻域点
 * @param piCurrentNode 当前节点
 * @return 返回领域节点
 */
vector<AStar::Node *> AStar::GetSurroundNodes(const Node *piCurrentNode)
{
    vector<Node *> vSurroundNodes;
    for (int i = piCurrentNode->m_nx - 1; i <= piCurrentNode->m_nx + 1; ++i)
        for (int j = piCurrentNode->m_ny - 1; j <= piCurrentNode->m_ny + 1; ++j)
        {
            //如果斜着走但是拐点处有障碍则无法通过
            if (IsReachable(piCurrentNode, new Node(i, j)))
            {
                if(i==piCurrentNode->m_nx - 1 && j==piCurrentNode->m_ny - 1 && (m_iMap.at<uchar>(j,i+1)==0||m_iMap.at<uchar>(j+1,i)==0))
                    continue;
                if(i==piCurrentNode->m_nx - 1 && j==piCurrentNode->m_ny + 1 && (m_iMap.at<uchar>(j-1,i)==0||m_iMap.at<uchar>(j,i+1)==0))
                    continue;
                if(i==piCurrentNode->m_nx + 1 && j==piCurrentNode->m_ny - 1 && (m_iMap.at<uchar>(j,i-1)==0||m_iMap.at<uchar>(j+1,i)==0))
                    continue;
                if(i==piCurrentNode->m_nx + 1 && j==piCurrentNode->m_ny + 1 && (m_iMap.at<uchar>(j,i-1)==0||m_iMap.at<uchar>(j-1,i)==0))
                    continue;
                vSurroundNodes.push_back(new Node(i, j));
            }
        }
    return vSurroundNodes;
}

/**
 * @brief AStar::GetLeastGNode 返回开列表中的F值最小的点
 * @return  返回的节点
 */
AStar::Node *AStar::GetLeastFNode()
{
    if (!m_vOpenList.empty())
    {
        Node* piMinFNode = m_vOpenList.front();
        for (auto &Node : m_vOpenList)
            if (Node->m_nF < piMinFNode->m_nF)
                piMinFNode = Node;
        return piMinFNode;
    }
    return NULL;
}

/**
 * @brief AStar::CalcG 计算G,欧式距离
 * @param piNode    当前节点
 * @param iEndNode  目标节点
 * @return  距离返回值
 */
int AStar::CalcG(Node *piNode)
{
    int nParentG = piNode->m_pParent==NULL?0:piNode->m_pParent->m_nG;
    int nTempG = pow(piNode->m_nx-piNode->m_pParent->m_nx,2)+pow(piNode->m_ny-piNode->m_pParent->m_ny,2);
    nTempG = sqrt(nTempG)*10;
    return nTempG+nParentG;
}

/**
 * @brief AStar::CalcH 计算H,欧式距离
 * @param piNode 当前节点
 * @param iEndNode  目标节点
 * @return  距离返回值
 */
int AStar::CalcH(AStar::Node *piNode, AStar::Node iEndNode)
{
    int nTempH = abs(iEndNode.m_nx - piNode->m_nx) + abs(iEndNode.m_ny - piNode->m_ny);
    return nTempH;
}

/**
 * @brief CAStar::GetMap 提供获取地图的接口
 * @return  返回地图
 */
std::vector<std::vector<int> > AStar::GetMap()
{
    return m_iMap;
}

/**
 * @brief AStar::DeleteNode 从列表中删除点
 * @param vList 节点列表
 * @param piNode    节点
 */
void AStar::DeleteNode(vector<Node *> &vList, Node *piNode)
{
    int nPos=0;
    for (uint i = 0; i != vList.size(); ++i)
    {
        if (vList[i]->m_nx == piNode->m_nx && vList[i]->m_ny == piNode->m_ny)
            break;
        ++nPos;
    }
    vList.erase(vList.begin()+nPos);
}
/**
 * @brief CAStar::FindPath 寻找最短路径
 * @param iStartNode    起始位置
 * @param iEndNode      终点位置
 * @return
 */
AStar::Node *AStar::FindPath(Node &iStartNode, Node &iEndNode)
{
    m_vOpenList.push_back(new Node(iStartNode.m_nx, iStartNode.m_ny)); //起点放入开集
    while (!m_vOpenList.empty())
    {
        Node* piCurrentNode = GetLeastFNode(); //找到F值最小的点
        DeleteNode(m_vOpenList, piCurrentNode);   //从开集中删除
        m_vCloseList.push_back(piCurrentNode);   //放到关闭集
        vector<Node*> vSurroundPoints = GetSurroundNodes(piCurrentNode);//寻找周围点
        for (Node* &piTarget : vSurroundPoints)
        {
            //对某一个格子，如果它不在开启列表中，加入到开启列表，设置当前格为其父节点，计算FGH
            if (!IsInList(m_vOpenList, piTarget))
            {
                piTarget->m_pParent = piCurrentNode;
                piTarget->m_nG = CalcG(piTarget);
                piTarget->m_nH = CalcH(piTarget,iEndNode);
                piTarget->m_nF = piTarget->m_nG + piTarget->m_nH;
                m_vOpenList.push_back(piTarget);
            }
            //对某一个格子，它在开启列表中，计算F值, 如果比原来的大, 就什么都不做, 否则设置它的父节点为当前点,并更新F
            else
            {
                Node *piTemp = piTarget->m_pParent;
                piTarget->m_pParent = piCurrentNode;
                int nTempF = CalcG(piTarget)+CalcH(piTarget, iEndNode);
                if (nTempF <= piTarget->m_nF)
                {
                    piTarget->m_nG = CalcG(piTarget);
                    piTarget->m_nH = CalcH(piTarget,iEndNode);
                    piTarget->m_nF = piTarget->m_nG + piTarget->m_nH;
                }
                else
                {
                    piTarget->m_pParent = piTemp;
                }
            }
            //如果终点出现在开集中，表明找到了路径，并返回。
            if (IsInList(m_vOpenList, &iEndNode))
                return piTarget; //返回列表里的节点指针
        }
//        m_iMap[piCurrentNode->m_nx][piCurrentNode->m_ny] = 6;
    }
    return NULL;
}

/**
 * @brief CAStar::GetPath 绘制最短路径
 * @param iStartNode 起始位置
 * @param iEndNode  终点位置
 * @return 路径
 */
vector<AStar::Node *> AStar::GetPath(Node &iStartNode, Node &iEndNode)
{
    Node *piResult = FindPath(iStartNode, iEndNode);
    vector<Node *> vPath;
    //返回路径，如果没找到路径，返回空
    while (piResult)
    {
        vPath.insert(vPath.begin(), piResult);
        piResult = piResult->m_pParent;//最短路径为不断遍历当前点的父结点
    }
    return vPath;
}
/**
 * @brief AStar::GetTrajectory 获取规划路径
 * @param iMap  地图
 * @param vPathList 返回的规划路径
 */
void AStar::GetTrajectory(cv::Mat& iMap,std::vector<cv::Point>& vPathList)
{
    m_vOpenList.clear();     //开集
    m_vCloseList.clear();


    Node  sStartNode(vPathList[0].x,vPathList[0].y);
    Node sEndNode(vPathList[1].x,vPathList[1].y);
    iMap.copyTo(m_iMap);
    Node *piResult = FindPath(sStartNode, sEndNode);
    vPathList.resize(0);
    //返回路径，如果没找到路径，返回空
    while (piResult)
    {
        cv::Point sPoint;
        sPoint.x = piResult->m_nx;
        sPoint.y = piResult->m_ny;
        vPathList.insert(vPathList.begin(), sPoint);
        piResult = piResult->m_pParent;//最短路径为不断遍历当前点的父结点
    }
    return;
}
