#ifndef autotestlib_H
#define autotestlib_H

#include <EwayFunc/FuncInterface.h>

Declare_FunLibSymble


#include <opencv/cv.hpp>
#define zero_X  30
#define zero_Y  10
#define goal_X  29
#define goal_Y  20


struct MapPostion{
    eint m_dX;
    eint m_dY;
    edouble m_RZ;
};

class autotestlib:public CFuncInterface
{
public:
   autotestlib();
   virtual ~autotestlib();
   virtual eint Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut);
   virtual eint Destroy();
   virtual eint CheckMsgCode(eint nMsgCode);
   
   virtual void JobStart();
   virtual void JobFailed(eint nErrCode);
   virtual eint ProcSetFunParam(CSetParaMessage* piMsg);
   virtual eint ProcMotCmdDone(edouble dTimeStamp,CCmdDoneMessage* piCmdDone);
   virtual eint ProcTimer(edouble dTimeStamp);



protected:
   static void ThreadProc(eint nArgv);
   void ShowMap();
   eint GetMoveCommand(CWheelGoToPositionCmd& iCmd);

   eint GetTraj();
   eint SetParam(estring psParam);

   void SendMove();

   void getInit();
private:

   ebool isRun;
   ebool isArrived;

   std::vector<cv::Point> vPathList;
   std::vector<CWheelGoToPositionCmd> vCmd;

   cv::Point sStartPoint;
   cv::Point sEndPoint;
   edouble   m_dGlobalDirection;

   cv::Point m_iCurPos;
   edouble   m_dLastDirection;
   MapPostion CurrentPos;

   cv::Mat iMap;
   cv::Mat iExpanded;

   CEBaseThread* m_pThread;
   euint m_nCmdSN;
   DECLEAR_FIFMESSAGE_MAP
};

#endif // autotestlib_H
