#include "MergeTraj.h"
#include "ImageTool.h"

/**
 * @brief MergeTraj::Merge 合并轨迹
 * @param vPathList 合并完成地轨迹
 */
void MergeTraj::Merge(std::vector<cv::Point>& vPathList)
{
    std::vector<cv::Point> vResult;
    vResult.push_back(vPathList[0]);
    for(euint n=1;n<vPathList.size()-1;n++)
    {
        // 检验轨迹点是否朝向一致，如果是则视为可行路径点
       if(!IfSameDir(vPathList[n-1],vPathList[n],vPathList[n+1]))
            vResult.push_back(vPathList[n]);
    }
    vResult.push_back(vPathList[vPathList.size()-1]);
    vPathList = vResult;
    return;
}

/**
 * @brief MergeTraj::IfSameDir 检验是否方向一致
 * @param sP1   轨迹点1
 * @param sP2   轨迹点2
 * @param sP3   轨迹点3
 * @return          是否一致
 */
ebool MergeTraj::IfSameDir(cv::Point& sP1,cv::Point& sP2,cv::Point& sP3)
{
    edouble dDX1,dDY1,dDX2,dDY2;
    dDX1 = sP2.x-sP1.x;
    dDX2 = sP3.x-sP2.x;
    dDY1 = sP2.y-sP1.y;
    dDY2 = sP3.y-sP2.y;

    if(0==dDX1||0==dDX2)
    {
        if(dDX1==dDX2)
            return true;
        else
            return false;
    }

    if(IsFloatEqual(dDY1/dDX1,dDY2/dDX2))
        return true;
    else
        return false;
}
