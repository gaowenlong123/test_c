#include <iostream>
#include "DijkStra.h"
#include "AStar.h"
#include "ImageTool.h"
#include "MapExpand.h"
#include "MergeTraj.h"

using namespace std;

#define goal_X  29
#define goal_Y  23


int main(int argc, char *argv[])
{
    cv::Mat iCell;
    cv::Mat iExpanded;

    //读取图片
    cv::Mat iMap = cv::imread("../map.png",CV_LOAD_IMAGE_GRAYSCALE);

   cv::Mat iMap2 ;
   iMap.copyTo(iMap2);

    std::vector<cv::Point> vPathList;
    if(iMap.empty())
    {
        std::cout<<"map is empty!!!"<<std::endl;
        return -1;
    }

    cv::Point sStartPoint;
    cv::Point sEndPoint;
    sStartPoint.x = 2;
    sStartPoint.y = 28;
    sEndPoint.x = goal_X;
    sEndPoint.y = goal_Y;


    //将图片信息转成地图信息
    ImageTool::MapToCell(iMap,iCell);

    // 膨胀地图
    iExpanded = iCell;
    MapExpand::ExpandMap(iCell,iExpanded);


    //开始DijkStra规划
    vPathList.clear();
    vPathList.push_back(sStartPoint);
    vPathList.push_back(sEndPoint);
    DijkStra::GetTrajectory(iExpanded,vPathList);
//    for(euint n=0;n<vPathList.size();n++)
//    {
//        cv::Point sPoint;
//        sPoint.x =vPathList[n].x;
//        sPoint.y = vPathList[n].y;
//        ImageTool::DrawCell(iMap,sPoint);
//    }

    MergeTraj::Merge(vPathList);
    for(eint n=0;n<vPathList.size()-1;n++)
    {
        ImageTool::DrawLine(iMap,vPathList[n],vPathList[n+1]);
    }



    //开始AStar规划
    vPathList.clear();
    vPathList.push_back(sStartPoint);
    vPathList.push_back(sEndPoint);

    AStar::GetTrajectory(iExpanded,vPathList);

    //tiqu guai dian
    MergeTraj::Merge(vPathList);
    for(eint n=0;n<vPathList.size()-1;n++)
    {
        ImageTool::DrawLine(iMap2,vPathList[n],vPathList[n+1]);
    }


    cv::imshow("DijkStra", iMap);
    cv::imshow("AStar", iMap2);
    cv::waitKey(0);

    return 0;
}
