#ifndef MERGETRAJ_H
#define MERGETRAJ_H

#include <EwayCore/EwaySdkDefine.h>
#include <opencv/cv.hpp>

class MergeTraj
{
public:
    MergeTraj(){}
    static void Merge(std::vector<cv::Point>& vPathList);

    static ebool IfSameDir(cv::Point& sP1,cv::Point& sP2,cv::Point& sP3);
};

#endif // MERGETRAJ_H
