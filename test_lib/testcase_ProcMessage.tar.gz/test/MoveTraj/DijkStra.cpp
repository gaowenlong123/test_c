#include "DijkStra.h"
#include  "iostream"
#include<cmath>
using namespace std;
cv::Mat DijkStra::m_iMap = cv::Mat();                   //地图初始化
vector<DijkStra::Node *> DijkStra::m_vOpenList ={};     //开集初始化
vector<DijkStra::Node *> DijkStra::m_vCloseList = {};    //闭集初始化
/**
 * @brief DijkStar::IsInList 判断点Node是否在列表中
 * @param vList 列表
 * @param piNode    当前节点
 * @return  是否在列表里
 */
bool DijkStra::IsInList(const vector<Node *> &vList,const Node *piNode)
{
    for (Node* p : vList)
        if (p->m_nx == piNode->m_nx && p->m_ny == piNode->m_ny)//遍历闭列表,判断坐标是否相等
        {
            return true;
        }
    return false;
}


/**
 * @brief DijkStar::IsReachable 判断该点是否能到达
 * @param piTargetNode  目标节点
 * @return  是否目标节点
 */
bool DijkStra::IsReachable(const Node *piTargetNode)
{
    //如果点超出地图、不是上下左右、是障碍物、或者在闭列表中，返回false。反之。
    if (piTargetNode->m_nx < 0 || piTargetNode->m_nx > (int)(m_iMap.cols - 1)
        || piTargetNode->m_ny < 0 || piTargetNode->m_ny > (int)(m_iMap.rows - 1)
        || (int)m_iMap.at<uchar>(piTargetNode->m_ny,piTargetNode->m_nx)== 0
        || IsInList(m_vCloseList, piTargetNode))
        return false;
    else
        return true;
}

/**
 * @brief DijkStar::GetSurroundNodes    获取当前点的有效邻域点
 * @param piCurrentNode 当前节点
 * @return  返回邻域节点
 */
vector<DijkStra::Node *> DijkStra::GetSurroundNodes(const Node *piCurrentNode)
{
    vector<Node *> vSurroundNodes;
    for (int i = piCurrentNode->m_nx - 1; i <= piCurrentNode->m_nx + 1; ++i)
        for (int j = piCurrentNode->m_ny - 1; j <= piCurrentNode->m_ny + 1; ++j)
        {
            //如果斜着走但是拐点处有障碍则无法通过
            if (IsReachable(new Node(i, j)))
            {
                if(i==piCurrentNode->m_nx - 1 && j==piCurrentNode->m_ny - 1 && (m_iMap.at<uchar>(j,i+1)==0||m_iMap.at<uchar>(j+1,i)==0))
                    continue;
                if(i==piCurrentNode->m_nx - 1 && j==piCurrentNode->m_ny + 1 && (m_iMap.at<uchar>(j-1,i)==0||m_iMap.at<uchar>(j,i+1)==0))
                    continue;
                if(i==piCurrentNode->m_nx + 1 && j==piCurrentNode->m_ny - 1 && (m_iMap.at<uchar>(j,i-1)==0||m_iMap.at<uchar>(j+1,i)==0))
                    continue;
                if(i==piCurrentNode->m_nx + 1 && j==piCurrentNode->m_ny + 1 && (m_iMap.at<uchar>(j,i-1)==0||m_iMap.at<uchar>(j-1,i)==0))
                    continue;
                vSurroundNodes.push_back(new Node(i, j));
            }
        }
    return vSurroundNodes;
}
/**
 * @brief DijkStar::GetLeastGNode   返回开列表中的G值最小的点
 * @return  G值最小的节点
 */
DijkStra::Node *DijkStra::GetLeastGNode()
{
    if (!m_vOpenList.empty())
    {
        Node* piMinGNode = m_vOpenList.front();
        for (auto &Node : m_vOpenList)
            if (Node->m_nG < piMinGNode->m_nG)
                piMinGNode = Node;
        return piMinGNode;
    }
    return NULL;
}

/**
 * @brief DijkStar::DeleteNode  从列表中删除点
 * @param vList 列表
 * @param piNode    当前节点
 */
void DijkStra::DeleteNode(vector<Node *> &vList, Node *piNode)
{
    int nPos=0;
    for (uint i = 0; i != vList.size(); ++i)
    {
        if (vList[i]->m_nx == piNode->m_nx && vList[i]->m_ny == piNode->m_ny)
            break;
        ++nPos;
    }
    vList.erase(vList.begin()+nPos);
}
/**
 * @brief DijkStar::CalcG   计算G,欧式距离
 * @param piNode    当前节点
 * @return 计算的欧式距离
 */
int DijkStra::CalcG(Node *piNode)
{
    int nParentG = piNode->m_pParent==NULL?0:piNode->m_pParent->m_nG;
    int nTempG = pow(piNode->m_nx-piNode->m_pParent->m_nx,2)+pow(piNode->m_ny-piNode->m_pParent->m_ny,2);
    nTempG = sqrt(nTempG)*10;
    return nTempG+nParentG;

}
/**
 * @brief CDijkstra::FindPath 寻找最短路径
 * @param iStartNode   起始节点
 * @param iEndNode  目标节点
 * @return  列表里的节点指针
 */
DijkStra::Node *DijkStra::FindPath(Node &iStartNode, Node &iEndNode)
{
    m_vOpenList.push_back(new Node(iStartNode.m_nx, iStartNode.m_ny)); //起点放入开集
    while (!m_vOpenList.empty())
    {
        Node* piCurrentNode = GetLeastGNode(); //找到F值最小的点
        DeleteNode(m_vOpenList, piCurrentNode);   //从开集中删除
        m_vCloseList.push_back(piCurrentNode);   //放到关闭集
        vector<Node*> vSurroundPoints = GetSurroundNodes(piCurrentNode);//寻找周围点
        for (Node* &piTarget : vSurroundPoints)
        {
            //对某一个格子，如果它不在开启列表中，加入到开启列表，设置当前格为其父节点，计算G值
            if (!IsInList(m_vOpenList, piTarget))
            {
                piTarget->m_pParent = piCurrentNode;
                piTarget->m_nG = CalcG(piTarget);
                m_vOpenList.push_back(piTarget);
            }
            //对某一个格子，它在开启列表中，计算G值, 如果比原来的大, 就什么都不做, 否则设置它的父节点为当前点,并更新G
            else
            {
                Node *piTemp = piTarget->m_pParent;
                piTarget->m_pParent = piCurrentNode;
                int nTempG = CalcG(piTarget);
                if (nTempG <= piTarget->m_nG)
                {
                    piTarget->m_nG = nTempG;
                }
                else
                {
                    piTarget->m_pParent = piTemp;
                }
            }
            //如果终点出现在开集中，表明找到了路径，并返回。
            if (IsInList(m_vOpenList, &iEndNode))
                return piTarget; //返回列表里的节点指针
        }
    }
    return NULL;
}
/**
 * @brief DijkStar::GetTrajectory
 * @param iMap     需要被规划的地图
 * @param vPathList   需要返回的路径,初始有两条轨迹,第一个是起始点,第二个是终点
 */
void DijkStra::GetTrajectory(cv::Mat& iMap,std::vector<cv::Point>& vPathList)
{
    //建立初始节点
    Node  sStartNode(vPathList[0].x,vPathList[0].y);
    Node sEndNode(vPathList[1].x,vPathList[1].y);
    //给地图赋值
    iMap.copyTo(m_iMap);

    // findpath
    Node *piResult = FindPath(sStartNode, sEndNode);

    vPathList.resize(0);
    //返回路径，如果没找到路径，返回空
    while (piResult)
    {
        cv::Point sPoint;
        sPoint.x = piResult->m_nx;
        sPoint.y = piResult->m_ny;
        vPathList.insert(vPathList.begin(), sPoint);
        piResult = piResult->m_pParent;//最短路径为不断遍历当前点的父结点
    }
    return;
}
