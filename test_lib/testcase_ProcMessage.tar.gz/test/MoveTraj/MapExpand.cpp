#include "MapExpand.h"
#include "iostream"
/**
 * @brief MapExpand::ExpandMap  地图膨胀
 * @param iOrigMap  原始地图
 * @param iExpanded 膨胀后的地图
 */

#define ExpandSize 1

void MapExpand::ExpandMap(cv::Mat& iOrigMap,cv::Mat& iExpanded)
{
    iExpanded = iOrigMap.clone(); // 复制一份原始地图
    for (int i=0;i<iOrigMap.rows;i++)
    {
        for (int j=0;j<iOrigMap.cols;j++)
        {
            for (int k=i-ExpandSize;k<i+ExpandSize+1;k++)
            {
                for (int p=j-ExpandSize;p<j+ExpandSize+1;p++)
                {
                    int nRows,nCols;
                    nRows = k;
                    nCols = p;
                    if(k>iOrigMap.rows-1)
                    {
                        nRows = iOrigMap.rows-1;
                    }
                    if(k<0)
                    {
                        nRows = 0;
                    }
                    if(p>iOrigMap.cols-1)
                    {
                        nCols = iOrigMap.cols-1;
                    }
                    if(p<0)
                    {
                        nCols = 0;
                    }

                    if(iOrigMap.at<uchar>(nRows,nCols)==0)
                    {
                        iExpanded.at<uchar>(i,j)=0;
                    }
                }
            }
        }
    }
}
