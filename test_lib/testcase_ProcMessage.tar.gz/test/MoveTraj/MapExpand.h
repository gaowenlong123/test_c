#ifndef MAPEXPAND_H
#define MAPEXPAND_H

#include <opencv/cv.hpp>

class MapExpand
{
public:
    MapExpand(){}
    void static ExpandMap(cv::Mat& iOrigMap,cv::Mat& iExpanded);
};

#endif // MAPEXPAND_H
