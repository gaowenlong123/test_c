#include "testproc.h"
#include <EwayFunc/FuncSdkLib.h>

Declare_FunSdk_Lib(testproc)
Declare_Function_ID("cf18bd86-988c-43b5-88ac-f8b268ba6ac7")
Declare_Function_Priority(FunPri_Normal)

RegisterMessage_Start
RegisterMessage_End

BEGIN_FIFEMSG_MAP(testproc,CFuncInterface)
//MSG_FIFMAP(FunMsg_User+1,OnMessageProcess)
END_FIFMSG_MAP

testproc::testproc()
{
    m_nStage = 0;
    m_bCmdDone = true;
    m_bCurrentPosReady = false;

    m_bPlaneDone =false;
    m_bReadyTest = false;
    GoalPos.m_dX = 29;
    GoalPos.m_dY = 23;
}

testproc::~testproc()
{
}

eint testproc::Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut)
{
    bLimbAuthority = true;

    vFeatureList.push_back(SysCom_ID_LMsg_RobPos);

    vFeatureList.push_back(SysCom_ID_LMsg_Sonar);
    vFeatureList.push_back(SysCom_ID_LMsg_Laser);
    vFeatureList.push_back(SysCom_ID_Vision_Marker);

    TimeOut = 5;

    return ERR_NONE;
}
eint testproc::Destroy()
{
    return ERR_NONE;
}
eint testproc::CheckMsgCode(eint nMsgCode)
{
    if( nMsgCode ==  SysCom_ID_LMsg_RobPos){

        return MsgProcCode_Record;

    }else if (nMsgCode == SysCom_ID_LMsg_Sonar ) {

            return MsgProcCode_Notify;

    }else if (nMsgCode == SysCom_ID_LMsg_Laser ) {

            return MsgProcCode_Notify;

    }else if (nMsgCode == SysCom_ID_Vision_Marker ) {

            return MsgProcCode_Notify;
    }
}

void testproc::JobStart()
{
    SetTimer(200);

    while(1){
        if(GetMsgData(&RobPos)){
            CurrentPos.m_dX = RobPos.m_dX;
            CurrentPos.m_dY = RobPos.m_dY;
//            m_vecOriginalPos[2] = RobPos.m_dZ;
            m_odomTime = RobPos.m_dTimeStamp;
            if(RobPos.m_fLeftSpeed > -10000)
            {
                m_bCurrentPosReady = true;
                break;
            }

        }

    }


    // get path points  //  get vector fangxiang de xaingliang

    //starmove   in motioncomdone   reduce params

    return ;
}

void testproc::JobFailed(eint nErrCode)
{
    return ;
}


eint testproc::ProcTimer(edouble dTimeStamp)
{
    if(!IsReadyTest){
       return ERR_NONE;
    }

    //start test case

}

ebool testproc::IsReadyTest(){
    if(m_bReadyTest){
        return true;
    }
    if(m_bPlaneDone){
        GetMsgData(&RobPos);
        if(IsArrived(RobPos)){        // zou budao zen me ban
            m_bReadyTest = true;
            return true;
        }
    }
    return false;
}

ebool testproc::IsArrived(CBotPosMessage& RobPos)
{
    if( RobPos.m_dX > GoalPos.m_dX-0.2 &&  RobPos.m_dX<GoalPos.m_dX + 0.2
            && RobPos.m_dY > GoalPos.m_dY- 0.2 &&  RobPos.m_dY<GoalPos.m_dY + 0.2){
        return true;
    }

    return false;
}

eint testproc::ProcMotCmdDone(edouble dTimeStamp,CCmdDoneMessage* piCmdDone)
{

}

eint testproc::ProcVisionMarker(edouble dTimeStamp,CMarkerMessage* piMarkerList)
{

}

eint testproc::ProcSonarMsg(edouble dTimeStamp,CSonarMessage* piSonarMsg)
{

}

eint testproc::ProcLaserMsg(edouble dTimeStamp,CLaserScanMessage* piMsg)
{

}

