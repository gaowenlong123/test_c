#ifndef MOVECONST_H
#define MOVECONST_H

#include "vector"
#include <EwayFunc/FuncInterface.h>


using namespace std;


struct MapPostion{
    eint m_dX;
    eint m_dY;
};




typedef struct
{
    euint8 bCellVal;
}GlobalMapCell;

typedef struct
{
    euint8 bCellVal;
}LocalMapCell;


struct ShmGlobalMap{
    efloat fResolution;
    edouble dOriginX;
    edouble dOriginY;
    edouble dOriginZ;
    edouble dSizeX;
    edouble dSizeY;
    edouble dTimeStamp;
    GlobalMapCell  nCell[Map_Size][Map_Size];
};

struct ShmLocalMap{
    edouble dTimeStamp;
    efloat fResolution;
    edouble dOriginX;
    edouble dOriginY;
    edouble dOriginZ;
    edouble dSizeX;
    edouble dSizeY;
    LocalMapCell  nCell[Map_Size][Map_Size];
};


#endif // MOVECONST_H
